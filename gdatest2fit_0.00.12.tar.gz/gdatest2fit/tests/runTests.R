BiocGenerics:::testPackage("gdatest2fit")
