## ----global_options, include=FALSE---------------------------------------
knitr::opts_chunk$set(fig.width=12, fig.height=8, 
                      warning=FALSE, message=FALSE)

## ----eval=T, load_gdatest2fit--------------------------------------------
## Load libraries
library('gdatest2fit')
library(genefilter)
library(xtable)
library(boot)
library(pROC)
library(verification)
library(glmnet)

## ----eval=T, load_example_data-------------------------------------------
### clinical data
data(cBRCA)
### gene expression in BRCA tummor sample data
data(BRCA)
data(subBRCA)


## ----eval=F, data_build_subBRCA------------------------------------------
#  ### breast_carcinoma_estrogen_receptor_status?
#  ind.er <- cBRCA["er_status_by_ihc",]
#  table(t(ind.er))
#  
#  ### Create a dataset contain samples of BRCA
#  ### with positive/negative estrogen receptor status only
#  er <- data.frame(t(ind.er))
#  ypos <- subset(er, er_status_by_ihc == "Positive")
#  yneg <- subset(er, er_status_by_ihc == "Negative")
#  BRCApos <- subset(gsmBRCA, select = (rownames(ypos)))
#  BRCAneg <- subset(gsmBRCA, select = (rownames(yneg)))
#  subBRCA <- data.frame(cbind (BRCApos, BRCAneg))

## ----eval=T, colnames----------------------------------------------------
#load("subBRCA.rda")
head(colnames(subBRCA))

## ----eval=T, result2test-------------------------------------------------
### Create indicator for testing
status <- index01 <- c(rep(1, 785), rep(0, 230))

par(mfrow=c(1,3))
### ttest and wilcoxcon test result
outresult <- result2tests(dmat=log2(subBRCA+1), index=index01)
###

#cat("\nproportion of p-values\n")
tt1 <- outresult[[3]]
wt2 <- outresult[[4]]

### adjusted p-values
pval.ttest <- as.matrix(outresult[[1]])
pval.wtest <- as.matrix(outresult[[2]])
rownames(pval.ttest) <- rownames(subBRCA)
rownames(pval.wtest) <- rownames(subBRCA)

### sorted the pvalue
tpval.sort <- pval.ttest[order(pval.ttest),]
wpval.sort <- pval.wtest[order(pval.wtest),]

### the 10 genes with the smallest p-values
tpval.sort[1:10]
wpval.sort[1:10]

par(mfrow=c(1,1))

## ----eval=F, cv.glm------------------------------------------------------
#  ### without including gene selection procedure in the cross validation
#  rowid <- names(wpval.sort)[1:50]
#  gene50 <- subBRCA[rowid,]
#  
#  ex50 <- t(gene50)
#  colnames(ex50) <- rowid
#  
#  # create a dataset with containing only five genes
#  data50 <- data.frame (log2(ex50+1), status)
#  fit.1 <- glm (status ~ ., family = binomial(link=logit), data=data50)
#  cv.error <- cv.glm(data50, glmfit=fit.1, K=10)$delta
#  
#  ### the error rate for prediction
#  cv.error

## ----eval=T, cv_f--------------------------------------------------------
### we need to use the CV to show the true performance of predicting models
###############################################
### 10 fold cross validation
data.glm <- data.frame(log2(t(subBRCA)+1), status)
k = 10

outres <- cv.f(dat=data.glm, K=k, m=50)
res50 <- outres[[1]]
roc(res50$status2, res50$eta, plot=T)
AUC <- roc.area(res50$status2, res50$eta)
index.cv <- outres[[2]]

alldata <- data.frame(data.glm[,index.cv], status)
fitall <- glm (status ~ ., family = binomial(link=logit), data=alldata)
summary(fitall)

fit1 <- glm(status~ESR1 + GPR77 + FLJ45983 + ABAT  + ANXA9, family = binomial(link=logit), data=alldata )
summary(fit1)
###

## ----eval=F--------------------------------------------------------------
#  ### for fitting different # of predictors in the models
#  ### m = # of predictors (genes)
#  outres2 <- cv.f(dat=data.glm, K=k, m=10)
#  outres3 <- cv.f(dat=data.glm, K=k, m=20)
#  outres4 <- cv.f(dat=data.glm, K=k, m=25)
#  outres5 <- cv.f(dat=data.glm, K=k, m=50)
#  outres6 <- cv.f(dat=data.glm, K=k, m=75)
#  outres1 <- cv.f(dat=data.glm, K=k, m=5)

## ----eval=F--------------------------------------------------------------
#  outres1 <- cv.f(dat=data.glm, K=k, m=5)
#  index.cv <- outres1[[2]]
#  auc.val <- outres1[[3]]$A
#  auc.val
#  fitteddata <- data.frame(data.glm[,index.cv], status)
#  fitm1 <- glm (status ~ ., family = binomial(link=logit), data=fitteddata)
#  summary(fitm1)
#  

## ----eval=T, glmnet------------------------------------------------------

# data.glm <- data.frame(log2(t(subBRCA)+1), status)
# Create train set
xt.lasso <- (log2(t(subBRCA)+1))
# create test set
test.x <- (log2(t(subBRCA)+1))

fit.lasso <- glmnet(xt.lasso, status, family ="binomial", alpha=1)
pred<-predict(fit.lasso,newx=test.x, s=c(.01), type="link")

## ----eval=T, roc.plot----------------------------------------------------
# Create a ROC curve for predictive value under a naive approach
AUC.naive <- roc.area(status, pred)
AUC.naive

gname <- as.factor(colnames(data.glm[,-max(ncol(data.glm))]))

# Corresponding genes
beta.name<-gname[which(coef(fit.lasso, s=.01)!=0)]
# Parameter estimates for genes
beta.fit<-coef(fit.lasso, s=.01)[which(coef(fit.lasso, s=.01)!=0)]

### numbers of significant genes
length(beta.fit)

## ----eval=T, cv.glmnet---------------------------------------------------
set.seed(12358)
## 10 fold cross validation without gene selection procedure
cv.lasso <- cv.glmnet(xt.lasso, status, nfold=10, family="binomial", type.measure = "auc")
plot(cv.lasso)

cv.lasso$lambda.min

# Given the optimal lambda value, we have the AUC value
AUC <- max(cv.lasso$cvm)
cat("\nSummary of AUC Statistic")
AUC

# Corresponding genes
b.name<-gname[which(coef(cv.lasso, s="lambda.min")!=0)]
# Parameter estimates for genes
b.coef<-coef(cv.lasso)[which(coef(cv.lasso, s="lambda.min")!=0)]
length(b.coef)
b.name

## ----eval=F, cv.lasso----------------------------------------------------
#  ### K fold cross validation with gene selection
#  set.seed(125421)
#  #par(mfrow=c(1,2))
#  ncv.fit1 <- ncv.lasso (gex=data.glm, k1=5, k2=10, m=10000)
#  ### AUC statistic
#  aucstat <- ncv.fit1[[3]]
#  
#  # PLot the ROC
#  res <- ncv.fit1[[1]]
#  par(mfrow=c(1,1))
#  roc(res$status2, res[,2], plot=T, smooth=T, main=paste("ROC for fitting with m genes", sep=" " ))

## ----data_loading--------------------------------------------------------
##########################################################################
########### breast_carcinoma_estrogen_receptor_status #####################
##########################################################################
### explore the data
#data(subBRCA)
gmatBRCA <- as.matrix(subBRCA)
mean(subBRCA==0) #proportion of value=0 in first sample
#sum of the samples for each gene and show proportion of 0 genes
mean(rowSums(subBRCA)==0)

## ----DESeqDataSetFromMatrix----------------------------------------------
## convert to a DESeqDataSet object from a matrix
library("DESeq2")
typeInd <- factor(c(rep("Positive", 785), rep("negative", 230)))
dds <- DESeqDataSetFromMatrix(subBRCA, data.frame(typeInd), design = ~ typeInd) # transfer the data matrix to DESEQ dataset
dds

ind <- which(rowSums(assay(dds)) > 10000)
dds2 <- dds[ind,]

dim(dds2)

## ----eval=F--------------------------------------------------------------
#  ## fit model
#  dds2fit <- DESeq(dds2)

## ----eval=F, echo=F------------------------------------------------------
#  #load("dds2fit.robj")
#  load("res.rda")
#  load("resMLE.rda")

## ----eval=F--------------------------------------------------------------
#  ## get results
#  res <- results(dds2fit)

## ----eval=F--------------------------------------------------------------
#  res <- res[order(res$padj),] ## sort results based on adjusted p-value
#  res
#  load("res.rda")
#  head(res)[1:10]
#  mcols(res)$description
#  
#  ## summary of results
#  summary(res)
#  
#  
#  ## p-value histograms
#  par(mfrow=c(1,2))
#  hist(res$pvalue)
#  hist(res$padj)
#  par(mfrow=c(1,1))
#  
#  ## MA plot
#  plotMA(res, main="DESeq2", ylim=c(-2,2))
#  
#  
#  ## compare with MLE estimates
#  resMLE <- results(dds2fit, addMLE=TRUE)
#  #save(resMLE, file="resMLE.rda")
#  
#  head(resMLE, 5)
#  resMLE1 <- resMLE[order(resMLE$padj),]
#  head(resMLE, 5)
#  plotMA(resMLE, MLE=TRUE, main="unshrunken LFC", ylim=c(-2,2))
#  
#  ## plot counts for a specific gene (here the one with min adjust p-value)
#  plotCounts(dds2fit, gene=which.min(resMLE$padj), intgroup="typeInd")

## ----session_info--------------------------------------------------------
sessionInfo()

